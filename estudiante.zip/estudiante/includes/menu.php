<!--menu -->
<ul class="sidebar-menu">
  <li class="menu-header">Dashboard</li>
  <li>
    <a class="nav-link" href="panel1">
      <i class="fas fa-fire"></i>
      <span style="margin-left: 10px">Dashboard</span>
    </a>
  </li>
  <li>
    <a class="nav-link" href="biblioteca/library">
      <i class="fas fa-book-reader"></i>
      <span style="margin-left: 10px">Biblioteca General</span>
    </a>
  </li>
</ul>